/*******************************************************************************
* File Name: Vectrex_D0_D8.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Vectrex_D0_D8_ALIASES_H) /* Pins Vectrex_D0_D8_ALIASES_H */
#define CY_PINS_Vectrex_D0_D8_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"


/***************************************
*              Constants        
***************************************/
#define Vectrex_D0_D8_0			(Vectrex_D0_D8__0__PC)
#define Vectrex_D0_D8_0_INTR	((uint16)((uint16)0x0001u << Vectrex_D0_D8__0__SHIFT))

#define Vectrex_D0_D8_1			(Vectrex_D0_D8__1__PC)
#define Vectrex_D0_D8_1_INTR	((uint16)((uint16)0x0001u << Vectrex_D0_D8__1__SHIFT))

#define Vectrex_D0_D8_2			(Vectrex_D0_D8__2__PC)
#define Vectrex_D0_D8_2_INTR	((uint16)((uint16)0x0001u << Vectrex_D0_D8__2__SHIFT))

#define Vectrex_D0_D8_3			(Vectrex_D0_D8__3__PC)
#define Vectrex_D0_D8_3_INTR	((uint16)((uint16)0x0001u << Vectrex_D0_D8__3__SHIFT))

#define Vectrex_D0_D8_4			(Vectrex_D0_D8__4__PC)
#define Vectrex_D0_D8_4_INTR	((uint16)((uint16)0x0001u << Vectrex_D0_D8__4__SHIFT))

#define Vectrex_D0_D8_5			(Vectrex_D0_D8__5__PC)
#define Vectrex_D0_D8_5_INTR	((uint16)((uint16)0x0001u << Vectrex_D0_D8__5__SHIFT))

#define Vectrex_D0_D8_6			(Vectrex_D0_D8__6__PC)
#define Vectrex_D0_D8_6_INTR	((uint16)((uint16)0x0001u << Vectrex_D0_D8__6__SHIFT))

#define Vectrex_D0_D8_7			(Vectrex_D0_D8__7__PC)
#define Vectrex_D0_D8_7_INTR	((uint16)((uint16)0x0001u << Vectrex_D0_D8__7__SHIFT))

#define Vectrex_D0_D8_INTR_ALL	 ((uint16)(Vectrex_D0_D8_0_INTR| Vectrex_D0_D8_1_INTR| Vectrex_D0_D8_2_INTR| Vectrex_D0_D8_3_INTR| Vectrex_D0_D8_4_INTR| Vectrex_D0_D8_5_INTR| Vectrex_D0_D8_6_INTR| Vectrex_D0_D8_7_INTR))

#endif /* End Pins Vectrex_D0_D8_ALIASES_H */


/* [] END OF FILE */
