/*******************************************************************************
* File Name: SRAM_D0_D8.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_SRAM_D0_D8_ALIASES_H) /* Pins SRAM_D0_D8_ALIASES_H */
#define CY_PINS_SRAM_D0_D8_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"


/***************************************
*              Constants        
***************************************/
#define SRAM_D0_D8_0			(SRAM_D0_D8__0__PC)
#define SRAM_D0_D8_0_INTR	((uint16)((uint16)0x0001u << SRAM_D0_D8__0__SHIFT))

#define SRAM_D0_D8_1			(SRAM_D0_D8__1__PC)
#define SRAM_D0_D8_1_INTR	((uint16)((uint16)0x0001u << SRAM_D0_D8__1__SHIFT))

#define SRAM_D0_D8_2			(SRAM_D0_D8__2__PC)
#define SRAM_D0_D8_2_INTR	((uint16)((uint16)0x0001u << SRAM_D0_D8__2__SHIFT))

#define SRAM_D0_D8_3			(SRAM_D0_D8__3__PC)
#define SRAM_D0_D8_3_INTR	((uint16)((uint16)0x0001u << SRAM_D0_D8__3__SHIFT))

#define SRAM_D0_D8_4			(SRAM_D0_D8__4__PC)
#define SRAM_D0_D8_4_INTR	((uint16)((uint16)0x0001u << SRAM_D0_D8__4__SHIFT))

#define SRAM_D0_D8_5			(SRAM_D0_D8__5__PC)
#define SRAM_D0_D8_5_INTR	((uint16)((uint16)0x0001u << SRAM_D0_D8__5__SHIFT))

#define SRAM_D0_D8_6			(SRAM_D0_D8__6__PC)
#define SRAM_D0_D8_6_INTR	((uint16)((uint16)0x0001u << SRAM_D0_D8__6__SHIFT))

#define SRAM_D0_D8_7			(SRAM_D0_D8__7__PC)
#define SRAM_D0_D8_7_INTR	((uint16)((uint16)0x0001u << SRAM_D0_D8__7__SHIFT))

#define SRAM_D0_D8_INTR_ALL	 ((uint16)(SRAM_D0_D8_0_INTR| SRAM_D0_D8_1_INTR| SRAM_D0_D8_2_INTR| SRAM_D0_D8_3_INTR| SRAM_D0_D8_4_INTR| SRAM_D0_D8_5_INTR| SRAM_D0_D8_6_INTR| SRAM_D0_D8_7_INTR))

#endif /* End Pins SRAM_D0_D8_ALIASES_H */


/* [] END OF FILE */
