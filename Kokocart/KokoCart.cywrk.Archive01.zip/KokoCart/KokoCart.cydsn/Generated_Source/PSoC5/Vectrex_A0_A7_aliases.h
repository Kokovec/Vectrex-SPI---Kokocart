/*******************************************************************************
* File Name: Vectrex_A0_A7.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Vectrex_A0_A7_ALIASES_H) /* Pins Vectrex_A0_A7_ALIASES_H */
#define CY_PINS_Vectrex_A0_A7_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"


/***************************************
*              Constants        
***************************************/
#define Vectrex_A0_A7_0			(Vectrex_A0_A7__0__PC)
#define Vectrex_A0_A7_0_INTR	((uint16)((uint16)0x0001u << Vectrex_A0_A7__0__SHIFT))

#define Vectrex_A0_A7_1			(Vectrex_A0_A7__1__PC)
#define Vectrex_A0_A7_1_INTR	((uint16)((uint16)0x0001u << Vectrex_A0_A7__1__SHIFT))

#define Vectrex_A0_A7_2			(Vectrex_A0_A7__2__PC)
#define Vectrex_A0_A7_2_INTR	((uint16)((uint16)0x0001u << Vectrex_A0_A7__2__SHIFT))

#define Vectrex_A0_A7_3			(Vectrex_A0_A7__3__PC)
#define Vectrex_A0_A7_3_INTR	((uint16)((uint16)0x0001u << Vectrex_A0_A7__3__SHIFT))

#define Vectrex_A0_A7_4			(Vectrex_A0_A7__4__PC)
#define Vectrex_A0_A7_4_INTR	((uint16)((uint16)0x0001u << Vectrex_A0_A7__4__SHIFT))

#define Vectrex_A0_A7_5			(Vectrex_A0_A7__5__PC)
#define Vectrex_A0_A7_5_INTR	((uint16)((uint16)0x0001u << Vectrex_A0_A7__5__SHIFT))

#define Vectrex_A0_A7_6			(Vectrex_A0_A7__6__PC)
#define Vectrex_A0_A7_6_INTR	((uint16)((uint16)0x0001u << Vectrex_A0_A7__6__SHIFT))

#define Vectrex_A0_A7_7			(Vectrex_A0_A7__7__PC)
#define Vectrex_A0_A7_7_INTR	((uint16)((uint16)0x0001u << Vectrex_A0_A7__7__SHIFT))

#define Vectrex_A0_A7_INTR_ALL	 ((uint16)(Vectrex_A0_A7_0_INTR| Vectrex_A0_A7_1_INTR| Vectrex_A0_A7_2_INTR| Vectrex_A0_A7_3_INTR| Vectrex_A0_A7_4_INTR| Vectrex_A0_A7_5_INTR| Vectrex_A0_A7_6_INTR| Vectrex_A0_A7_7_INTR))

#endif /* End Pins Vectrex_A0_A7_ALIASES_H */


/* [] END OF FILE */
