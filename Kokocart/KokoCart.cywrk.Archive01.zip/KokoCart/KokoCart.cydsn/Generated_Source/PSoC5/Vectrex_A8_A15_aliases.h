/*******************************************************************************
* File Name: Vectrex_A8_A15.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Vectrex_A8_A15_ALIASES_H) /* Pins Vectrex_A8_A15_ALIASES_H */
#define CY_PINS_Vectrex_A8_A15_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"


/***************************************
*              Constants        
***************************************/
#define Vectrex_A8_A15_0			(Vectrex_A8_A15__0__PC)
#define Vectrex_A8_A15_0_INTR	((uint16)((uint16)0x0001u << Vectrex_A8_A15__0__SHIFT))

#define Vectrex_A8_A15_1			(Vectrex_A8_A15__1__PC)
#define Vectrex_A8_A15_1_INTR	((uint16)((uint16)0x0001u << Vectrex_A8_A15__1__SHIFT))

#define Vectrex_A8_A15_2			(Vectrex_A8_A15__2__PC)
#define Vectrex_A8_A15_2_INTR	((uint16)((uint16)0x0001u << Vectrex_A8_A15__2__SHIFT))

#define Vectrex_A8_A15_3			(Vectrex_A8_A15__3__PC)
#define Vectrex_A8_A15_3_INTR	((uint16)((uint16)0x0001u << Vectrex_A8_A15__3__SHIFT))

#define Vectrex_A8_A15_4			(Vectrex_A8_A15__4__PC)
#define Vectrex_A8_A15_4_INTR	((uint16)((uint16)0x0001u << Vectrex_A8_A15__4__SHIFT))

#define Vectrex_A8_A15_5			(Vectrex_A8_A15__5__PC)
#define Vectrex_A8_A15_5_INTR	((uint16)((uint16)0x0001u << Vectrex_A8_A15__5__SHIFT))

#define Vectrex_A8_A15_6			(Vectrex_A8_A15__6__PC)
#define Vectrex_A8_A15_6_INTR	((uint16)((uint16)0x0001u << Vectrex_A8_A15__6__SHIFT))

#define Vectrex_A8_A15_7			(Vectrex_A8_A15__7__PC)
#define Vectrex_A8_A15_7_INTR	((uint16)((uint16)0x0001u << Vectrex_A8_A15__7__SHIFT))

#define Vectrex_A8_A15_INTR_ALL	 ((uint16)(Vectrex_A8_A15_0_INTR| Vectrex_A8_A15_1_INTR| Vectrex_A8_A15_2_INTR| Vectrex_A8_A15_3_INTR| Vectrex_A8_A15_4_INTR| Vectrex_A8_A15_5_INTR| Vectrex_A8_A15_6_INTR| Vectrex_A8_A15_7_INTR))

#endif /* End Pins Vectrex_A8_A15_ALIASES_H */


/* [] END OF FILE */
