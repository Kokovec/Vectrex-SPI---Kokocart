/*******************************************************************************
* File Name: SRAM_A0_A7.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_SRAM_A0_A7_ALIASES_H) /* Pins SRAM_A0_A7_ALIASES_H */
#define CY_PINS_SRAM_A0_A7_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"


/***************************************
*              Constants        
***************************************/
#define SRAM_A0_A7_0			(SRAM_A0_A7__0__PC)
#define SRAM_A0_A7_0_INTR	((uint16)((uint16)0x0001u << SRAM_A0_A7__0__SHIFT))

#define SRAM_A0_A7_1			(SRAM_A0_A7__1__PC)
#define SRAM_A0_A7_1_INTR	((uint16)((uint16)0x0001u << SRAM_A0_A7__1__SHIFT))

#define SRAM_A0_A7_2			(SRAM_A0_A7__2__PC)
#define SRAM_A0_A7_2_INTR	((uint16)((uint16)0x0001u << SRAM_A0_A7__2__SHIFT))

#define SRAM_A0_A7_3			(SRAM_A0_A7__3__PC)
#define SRAM_A0_A7_3_INTR	((uint16)((uint16)0x0001u << SRAM_A0_A7__3__SHIFT))

#define SRAM_A0_A7_4			(SRAM_A0_A7__4__PC)
#define SRAM_A0_A7_4_INTR	((uint16)((uint16)0x0001u << SRAM_A0_A7__4__SHIFT))

#define SRAM_A0_A7_5			(SRAM_A0_A7__5__PC)
#define SRAM_A0_A7_5_INTR	((uint16)((uint16)0x0001u << SRAM_A0_A7__5__SHIFT))

#define SRAM_A0_A7_6			(SRAM_A0_A7__6__PC)
#define SRAM_A0_A7_6_INTR	((uint16)((uint16)0x0001u << SRAM_A0_A7__6__SHIFT))

#define SRAM_A0_A7_7			(SRAM_A0_A7__7__PC)
#define SRAM_A0_A7_7_INTR	((uint16)((uint16)0x0001u << SRAM_A0_A7__7__SHIFT))

#define SRAM_A0_A7_INTR_ALL	 ((uint16)(SRAM_A0_A7_0_INTR| SRAM_A0_A7_1_INTR| SRAM_A0_A7_2_INTR| SRAM_A0_A7_3_INTR| SRAM_A0_A7_4_INTR| SRAM_A0_A7_5_INTR| SRAM_A0_A7_6_INTR| SRAM_A0_A7_7_INTR))

#endif /* End Pins SRAM_A0_A7_ALIASES_H */


/* [] END OF FILE */
