/*******************************************************************************
* File Name: SRAM_A8_A15.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_SRAM_A8_A15_ALIASES_H) /* Pins SRAM_A8_A15_ALIASES_H */
#define CY_PINS_SRAM_A8_A15_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"


/***************************************
*              Constants        
***************************************/
#define SRAM_A8_A15_0			(SRAM_A8_A15__0__PC)
#define SRAM_A8_A15_0_INTR	((uint16)((uint16)0x0001u << SRAM_A8_A15__0__SHIFT))

#define SRAM_A8_A15_1			(SRAM_A8_A15__1__PC)
#define SRAM_A8_A15_1_INTR	((uint16)((uint16)0x0001u << SRAM_A8_A15__1__SHIFT))

#define SRAM_A8_A15_2			(SRAM_A8_A15__2__PC)
#define SRAM_A8_A15_2_INTR	((uint16)((uint16)0x0001u << SRAM_A8_A15__2__SHIFT))

#define SRAM_A8_A15_3			(SRAM_A8_A15__3__PC)
#define SRAM_A8_A15_3_INTR	((uint16)((uint16)0x0001u << SRAM_A8_A15__3__SHIFT))

#define SRAM_A8_A15_4			(SRAM_A8_A15__4__PC)
#define SRAM_A8_A15_4_INTR	((uint16)((uint16)0x0001u << SRAM_A8_A15__4__SHIFT))

#define SRAM_A8_A15_5			(SRAM_A8_A15__5__PC)
#define SRAM_A8_A15_5_INTR	((uint16)((uint16)0x0001u << SRAM_A8_A15__5__SHIFT))

#define SRAM_A8_A15_6			(SRAM_A8_A15__6__PC)
#define SRAM_A8_A15_6_INTR	((uint16)((uint16)0x0001u << SRAM_A8_A15__6__SHIFT))

#define SRAM_A8_A15_7			(SRAM_A8_A15__7__PC)
#define SRAM_A8_A15_7_INTR	((uint16)((uint16)0x0001u << SRAM_A8_A15__7__SHIFT))

#define SRAM_A8_A15_INTR_ALL	 ((uint16)(SRAM_A8_A15_0_INTR| SRAM_A8_A15_1_INTR| SRAM_A8_A15_2_INTR| SRAM_A8_A15_3_INTR| SRAM_A8_A15_4_INTR| SRAM_A8_A15_5_INTR| SRAM_A8_A15_6_INTR| SRAM_A8_A15_7_INTR))

#endif /* End Pins SRAM_A8_A15_ALIASES_H */


/* [] END OF FILE */
