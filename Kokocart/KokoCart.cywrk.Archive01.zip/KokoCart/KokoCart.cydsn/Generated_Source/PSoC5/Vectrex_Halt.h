/*******************************************************************************
* File Name: Vectrex_Halt.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Vectrex_Halt_H) /* Pins Vectrex_Halt_H */
#define CY_PINS_Vectrex_Halt_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Vectrex_Halt_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Vectrex_Halt__PORT == 15 && ((Vectrex_Halt__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    Vectrex_Halt_Write(uint8 value);
void    Vectrex_Halt_SetDriveMode(uint8 mode);
uint8   Vectrex_Halt_ReadDataReg(void);
uint8   Vectrex_Halt_Read(void);
void    Vectrex_Halt_SetInterruptMode(uint16 position, uint16 mode);
uint8   Vectrex_Halt_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the Vectrex_Halt_SetDriveMode() function.
     *  @{
     */
        #define Vectrex_Halt_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define Vectrex_Halt_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define Vectrex_Halt_DM_RES_UP          PIN_DM_RES_UP
        #define Vectrex_Halt_DM_RES_DWN         PIN_DM_RES_DWN
        #define Vectrex_Halt_DM_OD_LO           PIN_DM_OD_LO
        #define Vectrex_Halt_DM_OD_HI           PIN_DM_OD_HI
        #define Vectrex_Halt_DM_STRONG          PIN_DM_STRONG
        #define Vectrex_Halt_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define Vectrex_Halt_MASK               Vectrex_Halt__MASK
#define Vectrex_Halt_SHIFT              Vectrex_Halt__SHIFT
#define Vectrex_Halt_WIDTH              1u

/* Interrupt constants */
#if defined(Vectrex_Halt__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Vectrex_Halt_SetInterruptMode() function.
     *  @{
     */
        #define Vectrex_Halt_INTR_NONE      (uint16)(0x0000u)
        #define Vectrex_Halt_INTR_RISING    (uint16)(0x0001u)
        #define Vectrex_Halt_INTR_FALLING   (uint16)(0x0002u)
        #define Vectrex_Halt_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define Vectrex_Halt_INTR_MASK      (0x01u) 
#endif /* (Vectrex_Halt__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Vectrex_Halt_PS                     (* (reg8 *) Vectrex_Halt__PS)
/* Data Register */
#define Vectrex_Halt_DR                     (* (reg8 *) Vectrex_Halt__DR)
/* Port Number */
#define Vectrex_Halt_PRT_NUM                (* (reg8 *) Vectrex_Halt__PRT) 
/* Connect to Analog Globals */                                                  
#define Vectrex_Halt_AG                     (* (reg8 *) Vectrex_Halt__AG)                       
/* Analog MUX bux enable */
#define Vectrex_Halt_AMUX                   (* (reg8 *) Vectrex_Halt__AMUX) 
/* Bidirectional Enable */                                                        
#define Vectrex_Halt_BIE                    (* (reg8 *) Vectrex_Halt__BIE)
/* Bit-mask for Aliased Register Access */
#define Vectrex_Halt_BIT_MASK               (* (reg8 *) Vectrex_Halt__BIT_MASK)
/* Bypass Enable */
#define Vectrex_Halt_BYP                    (* (reg8 *) Vectrex_Halt__BYP)
/* Port wide control signals */                                                   
#define Vectrex_Halt_CTL                    (* (reg8 *) Vectrex_Halt__CTL)
/* Drive Modes */
#define Vectrex_Halt_DM0                    (* (reg8 *) Vectrex_Halt__DM0) 
#define Vectrex_Halt_DM1                    (* (reg8 *) Vectrex_Halt__DM1)
#define Vectrex_Halt_DM2                    (* (reg8 *) Vectrex_Halt__DM2) 
/* Input Buffer Disable Override */
#define Vectrex_Halt_INP_DIS                (* (reg8 *) Vectrex_Halt__INP_DIS)
/* LCD Common or Segment Drive */
#define Vectrex_Halt_LCD_COM_SEG            (* (reg8 *) Vectrex_Halt__LCD_COM_SEG)
/* Enable Segment LCD */
#define Vectrex_Halt_LCD_EN                 (* (reg8 *) Vectrex_Halt__LCD_EN)
/* Slew Rate Control */
#define Vectrex_Halt_SLW                    (* (reg8 *) Vectrex_Halt__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Vectrex_Halt_PRTDSI__CAPS_SEL       (* (reg8 *) Vectrex_Halt__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Vectrex_Halt_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Vectrex_Halt__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Vectrex_Halt_PRTDSI__OE_SEL0        (* (reg8 *) Vectrex_Halt__PRTDSI__OE_SEL0) 
#define Vectrex_Halt_PRTDSI__OE_SEL1        (* (reg8 *) Vectrex_Halt__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Vectrex_Halt_PRTDSI__OUT_SEL0       (* (reg8 *) Vectrex_Halt__PRTDSI__OUT_SEL0) 
#define Vectrex_Halt_PRTDSI__OUT_SEL1       (* (reg8 *) Vectrex_Halt__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Vectrex_Halt_PRTDSI__SYNC_OUT       (* (reg8 *) Vectrex_Halt__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(Vectrex_Halt__SIO_CFG)
    #define Vectrex_Halt_SIO_HYST_EN        (* (reg8 *) Vectrex_Halt__SIO_HYST_EN)
    #define Vectrex_Halt_SIO_REG_HIFREQ     (* (reg8 *) Vectrex_Halt__SIO_REG_HIFREQ)
    #define Vectrex_Halt_SIO_CFG            (* (reg8 *) Vectrex_Halt__SIO_CFG)
    #define Vectrex_Halt_SIO_DIFF           (* (reg8 *) Vectrex_Halt__SIO_DIFF)
#endif /* (Vectrex_Halt__SIO_CFG) */

/* Interrupt Registers */
#if defined(Vectrex_Halt__INTSTAT)
    #define Vectrex_Halt_INTSTAT            (* (reg8 *) Vectrex_Halt__INTSTAT)
    #define Vectrex_Halt_SNAP               (* (reg8 *) Vectrex_Halt__SNAP)
    
	#define Vectrex_Halt_0_INTTYPE_REG 		(* (reg8 *) Vectrex_Halt__0__INTTYPE)
#endif /* (Vectrex_Halt__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Vectrex_Halt_H */


/* [] END OF FILE */
