/*******************************************************************************
* File Name: SRAM_A8_A14.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_SRAM_A8_A14_ALIASES_H) /* Pins SRAM_A8_A14_ALIASES_H */
#define CY_PINS_SRAM_A8_A14_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"


/***************************************
*              Constants        
***************************************/
#define SRAM_A8_A14_0			(SRAM_A8_A14__0__PC)
#define SRAM_A8_A14_0_INTR	((uint16)((uint16)0x0001u << SRAM_A8_A14__0__SHIFT))

#define SRAM_A8_A14_1			(SRAM_A8_A14__1__PC)
#define SRAM_A8_A14_1_INTR	((uint16)((uint16)0x0001u << SRAM_A8_A14__1__SHIFT))

#define SRAM_A8_A14_2			(SRAM_A8_A14__2__PC)
#define SRAM_A8_A14_2_INTR	((uint16)((uint16)0x0001u << SRAM_A8_A14__2__SHIFT))

#define SRAM_A8_A14_3			(SRAM_A8_A14__3__PC)
#define SRAM_A8_A14_3_INTR	((uint16)((uint16)0x0001u << SRAM_A8_A14__3__SHIFT))

#define SRAM_A8_A14_4			(SRAM_A8_A14__4__PC)
#define SRAM_A8_A14_4_INTR	((uint16)((uint16)0x0001u << SRAM_A8_A14__4__SHIFT))

#define SRAM_A8_A14_5			(SRAM_A8_A14__5__PC)
#define SRAM_A8_A14_5_INTR	((uint16)((uint16)0x0001u << SRAM_A8_A14__5__SHIFT))

#define SRAM_A8_A14_6			(SRAM_A8_A14__6__PC)
#define SRAM_A8_A14_6_INTR	((uint16)((uint16)0x0001u << SRAM_A8_A14__6__SHIFT))

#define SRAM_A8_A14_INTR_ALL	 ((uint16)(SRAM_A8_A14_0_INTR| SRAM_A8_A14_1_INTR| SRAM_A8_A14_2_INTR| SRAM_A8_A14_3_INTR| SRAM_A8_A14_4_INTR| SRAM_A8_A14_5_INTR| SRAM_A8_A14_6_INTR))

#endif /* End Pins SRAM_A8_A14_ALIASES_H */


/* [] END OF FILE */
