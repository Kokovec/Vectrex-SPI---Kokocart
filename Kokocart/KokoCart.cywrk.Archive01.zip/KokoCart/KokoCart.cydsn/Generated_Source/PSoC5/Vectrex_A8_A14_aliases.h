/*******************************************************************************
* File Name: Vectrex_A8_A14.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Vectrex_A8_A14_ALIASES_H) /* Pins Vectrex_A8_A14_ALIASES_H */
#define CY_PINS_Vectrex_A8_A14_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"


/***************************************
*              Constants        
***************************************/
#define Vectrex_A8_A14_0			(Vectrex_A8_A14__0__PC)
#define Vectrex_A8_A14_0_INTR	((uint16)((uint16)0x0001u << Vectrex_A8_A14__0__SHIFT))

#define Vectrex_A8_A14_1			(Vectrex_A8_A14__1__PC)
#define Vectrex_A8_A14_1_INTR	((uint16)((uint16)0x0001u << Vectrex_A8_A14__1__SHIFT))

#define Vectrex_A8_A14_2			(Vectrex_A8_A14__2__PC)
#define Vectrex_A8_A14_2_INTR	((uint16)((uint16)0x0001u << Vectrex_A8_A14__2__SHIFT))

#define Vectrex_A8_A14_3			(Vectrex_A8_A14__3__PC)
#define Vectrex_A8_A14_3_INTR	((uint16)((uint16)0x0001u << Vectrex_A8_A14__3__SHIFT))

#define Vectrex_A8_A14_4			(Vectrex_A8_A14__4__PC)
#define Vectrex_A8_A14_4_INTR	((uint16)((uint16)0x0001u << Vectrex_A8_A14__4__SHIFT))

#define Vectrex_A8_A14_5			(Vectrex_A8_A14__5__PC)
#define Vectrex_A8_A14_5_INTR	((uint16)((uint16)0x0001u << Vectrex_A8_A14__5__SHIFT))

#define Vectrex_A8_A14_6			(Vectrex_A8_A14__6__PC)
#define Vectrex_A8_A14_6_INTR	((uint16)((uint16)0x0001u << Vectrex_A8_A14__6__SHIFT))

#define Vectrex_A8_A14_INTR_ALL	 ((uint16)(Vectrex_A8_A14_0_INTR| Vectrex_A8_A14_1_INTR| Vectrex_A8_A14_2_INTR| Vectrex_A8_A14_3_INTR| Vectrex_A8_A14_4_INTR| Vectrex_A8_A14_5_INTR| Vectrex_A8_A14_6_INTR))

#endif /* End Pins Vectrex_A8_A14_ALIASES_H */


/* [] END OF FILE */
