/*******************************************************************************
* File Name: SPIS_C64_PM.c
* Version 2.70
*
* Description:
*  This file contains the setup, control and status commands to support
*  component operations in low power mode.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "SPIS_C64_PVT.h"

static SPIS_C64_BACKUP_STRUCT SPIS_C64_backup = 
{
    SPIS_C64_DISABLED,
    SPIS_C64_BITCTR_INIT,
};


/*******************************************************************************
* Function Name: SPIS_C64_SaveConfig
********************************************************************************
*
* Summary:
*  Empty function. Included for consistency with other components.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void SPIS_C64_SaveConfig(void) 
{

}


/*******************************************************************************
* Function Name: SPIS_C64_RestoreConfig
********************************************************************************
*
* Summary:
*  Empty function. Included for consistency with other components.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void SPIS_C64_RestoreConfig(void) 
{

}


/*******************************************************************************
* Function Name: SPIS_C64_Sleep
********************************************************************************
*
* Summary:
*  Prepare SPI Slave Component goes to sleep.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  SPIS_C64_backup - modified when non-retention registers are saved.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void SPIS_C64_Sleep(void) 
{
    /* Save components enable state */
    if ((SPIS_C64_TX_STATUS_ACTL_REG & SPIS_C64_INT_ENABLE) != 0u)
    {
        SPIS_C64_backup.enableState = 1u;
    }
    else /* Components block is disabled */
    {
        SPIS_C64_backup.enableState = 0u;
    }

    SPIS_C64_Stop();

}


/*******************************************************************************
* Function Name: SPIS_C64_Wakeup
********************************************************************************
*
* Summary:
*  Prepare SPIM Component to wake up.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  SPIS_C64_backup - used when non-retention registers are restored.
*  SPIS_C64_txBufferWrite - modified every function call - resets to
*  zero.
*  SPIS_C64_txBufferRead - modified every function call - resets to
*  zero.
*  SPIS_C64_rxBufferWrite - modified every function call - resets to
*  zero.
*  SPIS_C64_rxBufferRead - modified every function call - resets to
*  zero.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void SPIS_C64_Wakeup(void) 
{
    #if (SPIS_C64_TX_SOFTWARE_BUF_ENABLED)
        SPIS_C64_txBufferFull = 0u;
        SPIS_C64_txBufferRead = 0u;
        SPIS_C64_txBufferWrite = 0u;
    #endif /* SPIS_C64_TX_SOFTWARE_BUF_ENABLED */

    #if (SPIS_C64_RX_SOFTWARE_BUF_ENABLED)
        SPIS_C64_rxBufferFull = 0u;
        SPIS_C64_rxBufferRead = 0u;
        SPIS_C64_rxBufferWrite = 0u;
    #endif /* SPIS_C64_RX_SOFTWARE_BUF_ENABLED */

    SPIS_C64_ClearFIFO();

    /* Restore components block enable state */
    if (SPIS_C64_backup.enableState != 0u)
    {
         /* Components block was enabled */
         SPIS_C64_Enable();
    } /* Do nothing if components block was disabled */
}


/* [] END OF FILE */
