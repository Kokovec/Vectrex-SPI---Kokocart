/* ==========================================================================
 Kokocart
    This is a cartridge port adapter for the Vectrex.
    It includes the capability to load up to 64K ROMs a well as an SPI Peripheral.
    For more information see Vectorbolt issue #9 (http://furyunlimited.com/_sgg/m3_1.htm).
    by Dan Siewers

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
 * ===========================================================================
*/
#include "project.h"
#include <stdio.h>

#define waitEPIn while(USBUART_1_GetEPState(2) != USBUART_1_IN_BUFFER_EMPTY); // Wait until our IN EP is empty
#define USB_Enumerate 1
#define USB_Config 1
#define UART_Config 0
#define Internal_ROM 0


uint8 DataOut[50] = {};         // buffer for USB TX data
uint8 DataIn[50] = {};          // buffer for USB RX data
uint16 length;                  // length in bytes of the ROM file
uint8 LoadStart = 0;            // Flag used for reset button long presses
uint8 file_length_HI;
uint8 file_length_LO;
uint16 x;                       // general variable
uint16 y;                       // general variable
uint16 z;                       // general variable
uint8 a;                        // general variable
uint8 thedata;                  // data pulled from the SPI RX buffer
uint8 timer_tc_flag = 0;        // isr flag for reset button long press
uint8 isr_8000_flag = 0;        // isr flag for $8000 address capture

/* SRAM Write Initialization Function*/
void init_psoc_write_to_sram() {
    // disable outputs
    Control_Reg_SRAM_OE_Write(1);
    // setup device write
    Control_Reg_SRAM_WE_Write(0);
    // disable chip
    Control_Reg_SRAM_CE1_Write(1);
    //PSOC control of SRAM
    Control_Reg_Device_Select_Write(1);
}

/* SRAM Read Initialization Function*/
void init_psoc_read_sram(){
     // disable outputs
    Control_Reg_SRAM_OE_Write(0);
    // setup device read
    Control_Reg_SRAM_WE_Write(1);
    // disable chip
    Control_Reg_SRAM_CE1_Write(1);
    //PSOC control of SRAM
    Control_Reg_Device_Select_Write(1);
}

/* SRAM Write Function*/
void write_to_sram(uint16 writeaddress, uint8 writedata) {
    uint8 address_lo;
    uint8 address_hi;
    // load address
    address_lo = (uint8)writeaddress;
    address_hi = (uint8)(writeaddress >> 8);
    Control_Reg_SRAM_A0_A7_Write(address_lo);
    Control_Reg_SRAM_A8_A15_Write(address_hi);
    //load data
    Control_Reg_SRAM_D0_D8_Write(writedata);
    // cycle chip enable line
    Control_Reg_SRAM_CE1_Write(0);
    //CyDelayUs(10);
    Control_Reg_SRAM_CE1_Write(1);
    //CyDelayUs(10);
}

/* SRAM Read Function*/
uint8 read_from_sram(uint16 readaddress){
    uint8 address_lo;
    uint8 address_hi;
    // load address
    address_lo = (uint8)readaddress;
    address_hi = (uint8)(readaddress >> 8);
    Control_Reg_SRAM_A0_A7_Write(address_lo);
    Control_Reg_SRAM_A8_A15_Write(address_hi);
    // cycle chip enable line
    Control_Reg_SRAM_CE1_Write(0);
    //CyDelayUs(10);
    Control_Reg_SRAM_CE1_Write(1);
    //CyDelayUs(10);
    return SRAM_D0_D8_Read();
}

/* Vectrex reset button long press isr handler*/
void isr_RW_Handler() {
    timer_tc_flag = 1;
}

/* Address $8000 capture isr handler */
void isr_8000_Handler() {
    isr_8000_flag = 1;
}


int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    #if USB_Enumerate
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    USBUART_1_Start(0,USBUART_1_5V_OPERATION);
    //Wait for USB UART to enumerate
    while(!USBUART_1_bGetConfiguration());
    //Enable OUT enpoint (RX from computer to PSOC)
    USBUART_1_EnableOutEP(3);
    #endif
    
    SPIS_C64_Start();
    SPIS_C64_ClearRxBuffer();
    SPIS_C64_ClearTxBuffer();
    isr_RW_StartEx(isr_RW_Handler);     
    isr_8000_StartEx(isr_8000_Handler);
    Clock_Timer_Start();
    Timer_RW_Start();
    
    for(;;)
    {
        // Halt Vectrex        
        Control_Reg_Vectrex_Halt_Write(0);
        CyDelay(10);
        // PSOC control of SRAM
        Control_Reg_Device_Select_Write(1);
        // Assume <=32K for now
        Control_Reg_Vectrex_PB6_Select_Write(1);
        LoadStart = 0;
        #if USB_Config
        // Wait for ping from software loader
        // PC sends 0xA5 as a ping and PSOC sends back 0x5A as a response
        while(LoadStart == 0) {
            while(USBUART_1_GetEPState(3) == USBUART_1_OUT_BUFFER_EMPTY); // Wait until we have data
            length = USBUART_1_GetEPCount(3); // Get the length of received data
            USBUART_1_ReadOutEP(3, DataIn, length); // Get the data
            if(DataIn[0] == 0xA5) {
                DataOut[0] = 0x5A;
                waitEPIn
                USBUART_1_LoadInEP(2, DataOut, 1);
                LoadStart = 1;
            }
        }
        #endif
        
        #if USB_Config
        // send back file length as received
        while(USBUART_1_GetEPState(3) == USBUART_1_OUT_BUFFER_EMPTY); // Wait until we have data
        while(length < 2) {
            length = USBUART_1_GetEPCount(3); // Get the length of received data
        }
        USBUART_1_ReadOutEP(3, DataIn, length); // Get the data
        file_length_HI = DataIn[0];
        file_length_LO = DataIn[1];
        waitEPIn
        USBUART_1_LoadInEP(2, DataIn, 2);
        #endif
        
        #if !Internal_ROM
        x = file_length_HI << 8;
        x = x | file_length_LO;
        // Check if Bank switched ROM
        if(x > 32768) {
            Control_Reg_Vectrex_PB6_Select_Write(0);
        }
        init_psoc_write_to_sram();
        LoadStart = 0;
        y = 0;
        #endif
        
        
        #if USB_Config
        // Receive ROM data
        for(y=0; y<x; y++) {
            while(USBUART_1_GetEPState(3) == USBUART_1_OUT_BUFFER_EMPTY); // Wait until we have data
            //length = USBUART_1_GetEPCount(3); // Get the length of received data
            USBUART_1_ReadOutEP(3, DataIn, 1); // Get the data;
            //waitEPIn
            //USBUART_1_LoadInEP(2, DataIn, 1);
            write_to_sram(y, DataIn[0]);
        }
        #endif

        
        #if Internal_ROM
        init_psoc_write_to_sram();
        for(x=0; x<gamelength; x++) {
            write_to_sram(x, game[x]);
        }
        #endif
       
        
        // verify SRAM data integrity
        // Send SRAM data back to PC for verification
        #if USB_Config
        init_psoc_read_sram();
        for(y=0; y<x; y++){
            DataOut[0] = read_from_sram(y);
            waitEPIn
            USBUART_1_LoadInEP(2, DataOut,1);
        }
        waitEPIn
        #endif
        
        // Reset IO Lines
        init_psoc_write_to_sram();
        Control_Reg_SRAM_A0_A7_Write(0);
        Control_Reg_SRAM_A8_A15_Write(0);
        Control_Reg_SRAM_D0_D8_Write(0);
        // Start Vectrex        
        Control_Reg_Vectrex_Halt_Write(1);
        CyDelay(10);
        // SRAM Control back to Vectrex
        Control_Reg_Device_Select_Write(0);
         // disable outputs
        Control_Reg_SRAM_OE_Write(1);
        // setup device write
        Control_Reg_SRAM_WE_Write(0);
        // disable chip
        Control_Reg_SRAM_CE1_Write(1);
        // prep for write to $7FFD
        Control_Reg_SRAM_A0_A7_Write(0xFD);
        Control_Reg_SRAM_A8_A15_Write(0x7F);
        SPIS_C64_ClearRxBuffer();
        SPIS_C64_ClearTxBuffer();
        
        LoadStart = 0;
        // Check for PC App UI reset button press
        while(LoadStart == 0) {
            if(USBUART_1_GetEPState(3) != USBUART_1_OUT_BUFFER_EMPTY) {
                USBUART_1_ReadOutEP(3, DataIn, 1); // Get the data;
                if(DataIn[0] == 0x5A) {
                    DataIn[0] = 0xA5;
                    USBUART_1_LoadInEP(2, DataIn, 1);
                    waitEPIn
                    LoadStart = 1;
                }
            }
            
            // Check for Vectrex reset button held for 2 seconds
            if(timer_tc_flag == 1) {
                DataIn[0] = 0xBD;
                USBUART_1_LoadInEP(2, DataIn, 1);
                waitEPIn
                timer_tc_flag = 0;
                LoadStart = 1;
            }
            
            /*  Here when Vectrex requests data from SPI Peripheral
                Vectrex places value to send to C64 in $7FFF
                Vectrex reads value from C64 from $7FFE 
            */
            if(isr_8000_flag == 1) {
                /* Pull data from $7FFF */
                // enable outputs
                Control_Reg_SRAM_OE_Write(0);
                // setup device read
                Control_Reg_SRAM_WE_Write(1);
                // set address to $7FFF
                Control_Reg_SRAM_A0_A7_Write(0xFF);
                // wait for Vectrex to not be looking at SRAM
                CyDelayUs(3);
                //PSOC control of SRAM
                Control_Reg_Device_Select_Write(1);
                // cycle chip enable line
                Control_Reg_SRAM_CE1_Write(0);
                // Get Data to send out SPI interface
                thedata = SRAM_D0_D8_Read();
                Control_Reg_SRAM_CE1_Write(1);
                /*  Pull SPI data from SPI and save in $7FFE */
                // disable outputs
                Control_Reg_SRAM_OE_Write(1);
                // setup device write
                Control_Reg_SRAM_WE_Write(0);
                // set address to $7FFE
                Control_Reg_SRAM_A0_A7_Write(0xFE);
                //get data via SPI
                if(SPIS_C64_GetRxBufferSize() != 0) {
                    a = SPIS_C64_ReadRxData();
                    Control_Reg_SRAM_D0_D8_Write(a);
                }
                else {
                    a = 0x00;
                    Control_Reg_SRAM_D0_D8_Write(a);
                }
                // cycle chip enable line
                Control_Reg_SRAM_CE1_Write(0);
                Control_Reg_SRAM_CE1_Write(1);
                //Vectrex control of SRAM
                Control_Reg_Device_Select_Write(0);
                // Send to SPI interface
                if(SPIS_C64_GetTxBufferSize() < 254) {
                    if(thedata > 0) {
                        SPIS_C64_WriteTxData(thedata);
                    }
                }
                isr_8000_flag = 0;
            }
        }
    }
}

/* [] END OF FILE */
