import os
import serial
import sys
import glob
import tkinter as tk
from tkinter import filedialog
from tkinter.ttk import *
import binascii


# Search for serial ports
def serial_ports():
    """ Lists serial port names

        :raises EnvironmentError:
            On unsupported or unknown platforms
        :returns:
            A list of the serial ports available on the system
    """
    if sys.platform.startswith('win'):
        ports = ['COM%s' % (i + 1) for i in range(256)]
    elif sys.platform.startswith('linux') or sys.platform.startswith('cygwin'):
        # this excludes your current terminal "/dev/tty"
        ports = glob.glob('/dev/tty[A-Za-z]*')
    elif sys.platform.startswith('darwin'):
        ports = glob.glob('/dev/tty.*')
    else:
        raise EnvironmentError('Unsupported platform')

    result = []
    for port in ports:
        try:
            s = serial.Serial(port)
            s.close()
            result.append(port)
        except (OSError, serial.SerialException):
            pass
    return result


# Test for presence of Kokocart when COM is selected
def test_for_Vectrex_adapter(port):
    with serial.Serial(port, 57600, timeout=1) as ser:
        ser.write(serial.to_bytes([0xA5]))
        x = ser.read(1)
        if x != (serial.to_bytes([0x5A])):
            x = 0
        ser.close()
        #print(binascii.hexlify(serial.to_bytes(x)))
        return x


# Here when user selects from Comm Menu
def comhandler(value, button, label, menubutton):
    print("The Value:", value)
    if value != 'No COM':
        comvar.set(value)
        testcart = test_for_Vectrex_adapter(value)
        if testcart == serial.to_bytes([0x5A]):
            button["state"] = 'normal'
            COMOptionMenu['state'] = 'disabled'
            labelCart['text'] = "KokoCart Found"
            labelCart['background'] = "#34A2FE"
        else:
            labelCart['text'] = "No Board Detected"
            labelCart['background'] = "red"


# Here when Reset button pressed
def resethandler():
    with serial.Serial(comvar.get(), 57600, timeout=3) as ser:
        ser.write(serial.to_bytes([0x5A]))
        x = ser.read(1)
        if x == serial.to_bytes([0xA5]):
            labelFile['text'] = "File Name:"
            ResetButton['state'] = 'disable'
            labelCart['text'] = 'Kokocart Not Detected'
            labelCart['background'] = "red"
            labelProgress['text'] = "Load"
            labelVerify['text'] = "Not Verified"
            labelVerify['background'] = "red"
            progress['value'] = 0
            labelFilelength['text'] = 0
            ser.write(serial.to_bytes([0xA5]))
            if ser.read(1) == (serial.to_bytes([0x5A])):
                COMButton["state"] = 'normal'
                COMOptionMenu['state'] = 'disabled'
                labelCart['text'] = "KokoCart Found"
                labelCart['background'] = "#34A2FE"
            ser.close()

# Wait for user to press and hold reset button on the Vectrex
def vectrex_reset():
    with serial.Serial(comvar.get(), 57600, timeout=1) as ser:
        while True:
            c = ser.read()
            if c == 0:
                stopfunc = False
                break;
            if c == serial.to_bytes([0xBD]):
                labelFile['text'] = "File Name:"
                #ResetButton['state'] = 'disable'
                labelCart['text'] = 'Kokocart Not Detected'
                labelCart['background'] = "red"
                labelProgress['text'] = "Load"
                labelVerify['text'] = "Not Verified"
                labelVerify['background'] = "red"
                progress['value'] = 0
                labelFilelength['text'] = 0
                ser.write(serial.to_bytes([0xA5]))
                if ser.read(1) == (serial.to_bytes([0x5A])):
                    COMButton["state"] = 'normal'
                    COMOptionMenu['state'] = 'disabled'
                    labelCart['text'] = "KokoCart Found"
                    labelCart['background'] = "#34A2FE"
                ser.close()
                stopfunc = True
        if stopfunc == False:
            ser.close()
            topwindow.after(100, vectrex_reset)


# Here to select a file and send to Kokocart
def getfile(root):
    root.filename = filedialog.askopenfilename(initialdir="/", title="Select file",
                                               filetypes=(("bin files", "*.bin"), ("all files", "*.*")))
    labelFile['text'] = root.filename
    statinfo = os.stat(labelFile['text'])
    filesize = statinfo.st_size - 1
    labelFilelength['text'] = filesize
    progress['maximum'] = filesize
    topwindow.update_idletasks()
    #filesizeHI = filesize >> 8
    #filesizeLO = filesize & 255
    # Send to Kokocart
    with serial.Serial(comvar.get(), 57600, timeout=3) as ser:
        ser.write(filesize.to_bytes(2, 'big'))
        cartresponse = ser.read(2)
        print(cartresponse)
        if filesize / 10 >= 1:
            progressstep = int(round(filesize / 10, -2))
            #print(progressstep)
        else:
            progressstep = 1
        progressvalue = 0
        binary_file = open(root.filename, "rb")
        for a in range(filesize):
            tosend = binary_file.read(1)
            #print(binascii.hexlify(tosend))
            ser.write(tosend)
            #print(binascii.hexlify(ser.read(1)))
            progressvalue += 1
            if progressvalue == progressstep:
                progress['value'] = a
                topwindow.update_idletasks()
                progressvalue = 0
        progress['value'] = filesize
        topwindow.update_idletasks()
        binary_file.close()
        binary_file = open(root.filename, "rb")
        errors = 0
        progressvalue = 0
        labelProgress['text'] = "Verifying"
        # Verify for errors (Kokocart SRAM vs BIN file)
        for a in range(filesize):
            tocompare = binary_file.read(1)
            forcompare = ser.read(1)
            #print(str(binascii.hexlify(tocompare)) + " " + str(binascii.hexlify(forcompare)))
            if tocompare != forcompare:
                errors += 1
                print(str(binascii.hexlify(tocompare)) + " " + str(binascii.hexlify(forcompare)))
                # print("Error!")
            progressvalue += 1
            if progressvalue == progressstep:
                progress['value'] = a
                topwindow.update_idletasks()
                progressvalue = 0
        progress['value'] = filesize
        if errors:
            labelVerify['text'] = "Verify Errors"
        else:
            labelVerify['text'] = "Verify Pass"
            labelVerify['background'] = "#34A2FE"
            #ResetButton['state'] = 'normal'
        binary_file.close()
        ser.close()
    COMButton['state'] = 'disable'
    topwindow.after(1000, vectrex_reset)
    print("Done")


listserial = []


if __name__ == '__main__':
    print(serial_ports())
    listserial[:] = serial_ports()
    topwindow = tk.Tk()
    topwindow.title("KoKoCart")
    topwindow.geometry('800x300')
    labelCOM = tk.Label(text="Choose COM Port:",
                        foreground="white",
                        background="#34A2FE",
                        width=20)
    labelFile = tk.Label(text="File Name:",
                        foreground="white",
                        background="#34A2FE",
                        width=0)
    labelCart = tk.Label(text="Kokocart Not Detected",
                         foreground="white",
                         background="red",
                         width=0)
    separator = Separator(orient='horizontal')
    labelProgress = tk.Label(text="Load",
                             foreground="white",
                             background="blue",
                             width=0)
    labelVerify = tk.Label(text="Not Verified",
                         foreground="white",
                         background="red",
                         width=0)
    progress = Progressbar(topwindow, orient='horizontal', length=300, mode='determinate')
    COMButton = tk.Button(topwindow, text='Choose File', state='disabled', command=lambda: getfile(topwindow))
    #ResetButton = tk.Button(topwindow, text='Reset', state='disabled', command=lambda: resethandler())
    comvar = tk.StringVar(topwindow)
    if not listserial:
        comvar.set('No COM Ports')
        listserial.append('No COM')
    else:
        comvar.set("->")
    COMOptionMenu = tk.OptionMenu(topwindow, comvar, *listserial, command=lambda x: comhandler(comvar.get(), COMButton, labelCart, COMOptionMenu))
    labelFilelength = tk.Label(text="0",
                               foreground="white",
                               background="#34A2FE",
                               width=0)
    labelHtphen = tk.Label(text="Length=",
                               foreground="white",
                               background="#34A2FE",
                               width=0)

    topwindow.grid_rowconfigure(2, minsize=50)

    labelCOM.grid(row=0, column=0)
    COMOptionMenu.grid(row=0, column=1)
    labelCart.grid(row=0, column=2)
    COMButton.grid(row=1, column=0)
    labelFile.grid(row=1, column=1)
    labelHtphen.grid(row=1, column=2, sticky='e')
    labelFilelength.grid(row=1, column=3)
    separator.grid(row=2, columnspan=3, sticky="ew")
    labelProgress.grid(row=3, column=0, sticky='e')
    progress.grid(row=3, column=1)
    labelVerify.grid(row=4, column=1)
    #ResetButton.grid(row=5, column=0)
    topwindow.mainloop()




